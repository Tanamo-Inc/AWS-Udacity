from setuptools import setup

setup(name='tanacom_distributions',
      version='0.1',
      description='A test case of Gaussian distributions',
      packages=['distributions'],
      zip_safe=False)
